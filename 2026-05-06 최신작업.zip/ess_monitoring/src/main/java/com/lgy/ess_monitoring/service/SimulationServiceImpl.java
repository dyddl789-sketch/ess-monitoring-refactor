package com.lgy.ess_monitoring.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.ess_monitoring.dao.EssMonitoringDAO;
import com.lgy.ess_monitoring.dto.EssDeviceDTO;
import com.lgy.ess_monitoring.dto.EssMonitoringDTO;
import com.lgy.ess_monitoring.dto.WeatherDataDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SimulationServiceImpl implements SimulationService {

    @Autowired
    private EssDeviceService deviceService;

    @Autowired
    private WeatherDataService weatherDataService;

    @Autowired
    private SqlSession sqlSession;

    private EssMonitoringDAO getDao() {
        return sqlSession.getMapper(EssMonitoringDAO.class);
    }

    @Override
    public void runSimulation(int deviceId) {

        log.info("@# runSimulation() deviceId => {}", deviceId);

        try {

            // ===============================
            // 장비 정보 조회
            // ===============================
            EssDeviceDTO device =
                    deviceService.deviceDetail(deviceId);

            if (device == null) {
                log.warn("@# device 없음");
                return;
            }

            // ===============================
            // 현재 날씨 조회
            // ===============================
            WeatherDataDTO weather =
                    weatherDataService.getOrFetchCurrentWeather(deviceId);

            if (weather == null) {
                log.warn("@# weather 없음");
                return;
            }

            // ===============================
            // 날씨 기반 발전 효율 계산
            // ===============================
            double weatherFactor = 1.0;

            if ("맑음".equals(weather.getSkyStatus())) {
                weatherFactor = 1.0;

            } else if ("구름많음".equals(weather.getSkyStatus())) {
                weatherFactor = 0.7;

            } else if ("흐림".equals(weather.getSkyStatus())) {
                weatherFactor = 0.4;
            }

            // 비 오면 효율 감소
            if (weather.getRainType() != null
                    && !"없음".equals(weather.getRainType())) {

                weatherFactor *= 0.5;
            }

            // ===============================
            // 발전량 계산
            // ===============================
            double generation =
                    device.getCapacityKw()
                    * weatherFactor
                    * 0.85;

            // ===============================
            // 충전량 계산
            // ===============================
            double charged =
                    generation
                    * (device.getChargeEfficiency() / 100.0);

            // ===============================
            // 사용량 (임시 시뮬레이션)
            // ===============================
            double usedEnergy = generation * 0.6;

            // ===============================
            // 현재 충전량 계산
            // ===============================
            double currentCharge =
                    charged - usedEnergy;

            if (currentCharge < 0) {
                currentCharge = 0;
            }

            // ===============================
            // SOC 계산
            // ===============================
            double soc =
                    (currentCharge
                            / device.getEssCapacityKwh())
                            * 100.0;

            if (soc > 100) {
                soc = 100;
            }

            // ===============================
            // 전압 / 전류 계산
            // ===============================
            double voltage = 220 + (Math.random() * 10);

            double currentA =
                    generation * 4.5;

            // ===============================
            // 절감 금액
            // ===============================
            double savedCost =
                    generation
                    * device.getElectricityRate();

            // ===============================
            // DTO 생성
            // ===============================
            EssMonitoringDTO dto =
                    new EssMonitoringDTO();

            dto.setDeviceId(deviceId);

            dto.setVoltage(
                    BigDecimal.valueOf(voltage)
                            .setScale(2, RoundingMode.HALF_UP)
            );

            dto.setCurrentA(
                    BigDecimal.valueOf(currentA)
                            .setScale(2, RoundingMode.HALF_UP)
            );

            dto.setSoc(
                    BigDecimal.valueOf(soc)
                            .setScale(2, RoundingMode.HALF_UP)
            );

            dto.setPowerOutput(
                    BigDecimal.valueOf(generation)
                            .setScale(2, RoundingMode.HALF_UP)
            );

            dto.setSolarGenerationKwh(
                    BigDecimal.valueOf(generation)
                            .setScale(2, RoundingMode.HALF_UP)
            );

            dto.setChargedEnergyKwh(
                    BigDecimal.valueOf(charged)
                            .setScale(2, RoundingMode.HALF_UP)
            );

            dto.setUsedEnergyKwh(
                    BigDecimal.valueOf(usedEnergy)
                            .setScale(2, RoundingMode.HALF_UP)
            );

            dto.setSavedCost(
                    BigDecimal.valueOf(savedCost)
                            .setScale(2, RoundingMode.HALF_UP)
            );

            // ===============================
            // 저장
            // ===============================
            getDao().insertMonitoring(dto);

            log.info("@# monitoring 저장 완료");

        } catch (Exception e) {

            log.error("@# simulation error", e);
        }
    }
}
